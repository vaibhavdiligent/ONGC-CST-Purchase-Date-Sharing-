CIS 2026-27 - fix 25.11.2026: YRVG052 showed PP grade IHP120 OG (MPG N2) with a discount

1. abapGit (this zip > Import zip > Pull): YCIS_REBATE_REPORT (YRVG052)
   - grades not in YRVA_GRADE_CISD (e.g. PP) are not shown; the order's eligible qty / rebate value
     are split over the CIS grades only. Corrects records already captured - no data correction.
2. SE38 copy-paste (folder COPY_PASTE_SE38): YRVG004_QAIS_EXECUTE_N1 (YRVG004, L1) - 15800 lines
   - new L1 runs capture only the CIS grades in the grade-wise detail (YCIS_APPRVL_GRD).

The rebate orders / credit notes were correct - the PP quantity was never in the CIS discount.
