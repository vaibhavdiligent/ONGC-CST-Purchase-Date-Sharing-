CIS 2026-27 - PDR go-live package (17.11.2026)

1_CIS_2026_27_PDR_abapGit.zip  -> abapGit: Import > Offline > upload this zip, then Pull.
   YCIS_APPROVE, YCIS_EXECUTE, YCIS_VET, YCIS_APPRV5, YCIS_DISBURSE (CIS L2-L6),
   YCIS_REBATE_REPORT (YRVG052),
   YCIS_REB_APPROVE, YCIS_REB_EXECUTE, YCIS_REB_VET, YCIS_REB_APPRV5, YCIS_REB_DISBURSE (rebate L2-L6).

2_COPY_PASTE_SE38 -> open each program in SE38, replace the whole source, activate:
   YRVG004_QAIS_EXECUTE_N1.abap      (CIS L1)
   YRVG004_QAIS_EXECUTE_N1_old.abap  (PDR 3-level L1)
   Not in abapGit on purpose: their selection texts / text symbols are maintained only in SAP
   and an abapGit import would overwrite them.

Before release: SE11 ZCIS_APPR_NOTE_S field AMT_WORDS (CHAR 255); SFP form/interface
ZCIS_PSD_APPR_NOTE activated; GUI statuses STANDARD present; OB32 SGTXT (customizing request).
Strategic Monthly Discount is switched OFF (constant GC_SMD_ACTIVE = blank in L1-L6).
