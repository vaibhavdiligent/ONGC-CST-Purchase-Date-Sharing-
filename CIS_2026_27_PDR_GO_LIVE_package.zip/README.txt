CIS 2026-27 - PDR go-live package (18.11.2026) - Strategic Monthly Discount (SMD) switched OFF

STEP 1 - abapGit (11 programs)
   abapGit standalone: New Offline (or existing offline repo) > Import zip > Pull.
   YCIS_APPROVE, YCIS_EXECUTE, YCIS_VET, YCIS_APPRV5, YCIS_DISBURSE (CIS L2-L6:
   YRVG004_A / _E / _V / _F / _P),
   YCIS_REBATE_REPORT (YRVG052),
   YCIS_REB_APPROVE, YCIS_REB_EXECUTE, YCIS_REB_VET, YCIS_REB_APPRV5, YCIS_REB_DISBURSE (rebate L2-L6).

STEP 2 - SE38 copy-paste (folder COPY_PASTE_SE38, ignored by abapGit)
   Open the program in SE38 > Ctrl+A > Delete > paste the whole file > Save > Activate.
   YRVG004_QAIS_EXECUTE_N1.abap      (CIS L1, T-code YRVG004)  - 15782 lines
   YRVG004_QAIS_EXECUTE_N1_old.abap  (PDR 3-level L1)
   Not in abapGit on purpose: their selection texts / text symbols are maintained only in SAP
   and an abapGit import would overwrite them.

STEP 3 - check after loading (search with Ctrl+F in SE38)
   YRVG004_QAIS_EXECUTE_N1 : "r_addmj NO-DISPLAY" and "gc_smd_active" must be found
   YCIS_APPROVE / YCIS_EXECUTE / YCIS_VET / YCIS_APPRV5 / YCIS_DISBURSE : "gc_smd_active" must be found
   Run YRVG004, YRVG004_A, _E, _V, _F, _P : no "Strategic Monthly Discount" radio button.
   If a program does not contain gc_smd_active, the load did not reach it - load it again.

Before release: SE11 ZCIS_APPR_NOTE_S field AMT_WORDS (CHAR 255); SFP form/interface
ZCIS_PSD_APPR_NOTE activated; GUI statuses STANDARD present; OB32 SGTXT (customizing request).
To activate SMD later: set GC_SMD_ACTIVE = 'X' in L2-L6; in N1 also restore the radio-button
lines (see comment at PARAMETERS r_addmj).
