*&---------------------------------------------------------------------*
*& Report  YCIS_REB_VET
*&---------------------------------------------------------------------*
*& Rebate (PSD / YRVU001) - 6-level approval workflow : LEVEL 4
*& (CPC Finance - Financial Vetting).
*&
*&   L3 : YCIS_REB_EXECUTE creates the credit-memo request -> WF_STATUS '40'
*&        (Pending L4).  THIS program lists those Pending-L4 rebate rows for
*&        CPC Finance:
*&          VET (Approve) -> WF_STATUS '50' (Pending L5 - CPC Head), mail L5.
*&          REJECT        -> WF_STATUS '30' (back to L3), mail L3.
*&
*&   Rebate queue only (SCHEME_TYPE = 'U'); L4 is central (office '0001').
*&   GUI status 'STANDARD' (APPR, REJ, SELALL, DESEL, BACK/EXIT) - SE41
*&   (copy from YCIS_REB_APPROVE).
*&---------------------------------------------------------------------*
REPORT  ycis_reb_vet.

TYPE-POOLS: slis.

TABLES: ycis_apprvl, ycis_wf_appr.

CONSTANTS: gc_level  TYPE ycis_wlevel VALUE '4',              " this program = L4
           gc_scheme TYPE ycis_apprvl-scheme_type VALUE 'U'. " Upliftment Rebate

TYPES: BEGIN OF ty_out,
         sel        TYPE flag,
         kunnr      TYPE ycis_apprvl-kunnr,
         cust_name  TYPE ycis_apprvl-cust_name,
         kvgr2      TYPE ycis_apprvl-kvgr2,
         sales_off  TYPE ycis_apprvl-sales_off,
         reb_cond   TYPE ycis_apprvl-reb_cond,
         lft_qty    TYPE ycis_apprvl-lft_qty,
         elig_qty   TYPE ycis_apprvl-elig_qty,
         rebate_val TYPE ycis_apprvl-rebate_val,
         purch_no   TYPE ycis_apprvl-purch_no,
         order_no   TYPE ycis_apprvl-order_no,
         l1_user    TYPE ycis_apprvl-l1_user,
         l2_user    TYPE ycis_apprvl-l2_user,
         l3_user    TYPE ycis_apprvl-l3_user,
         l3_date    TYPE ycis_apprvl-l3_date,
         remarks    TYPE ycis_apprvl-remarks,
       END OF ty_out.

DATA: gt_appr   TYPE STANDARD TABLE OF ycis_apprvl,
      gs_appr   TYPE ycis_apprvl,
      gt_out    TYPE STANDARD TABLE OF ty_out,
      gs_out    TYPE ty_out,
      gt_fcat   TYPE slis_t_fieldcat_alv,
      gs_fcat   TYPE slis_fieldcat_alv,
      gs_layout TYPE slis_layout_alv,
      gv_auth   TYPE flag.

*--------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-001.
SELECT-OPTIONS: s_sptag FOR ycis_apprvl-period_from,
                s_vkbur FOR ycis_apprvl-sales_off,
                s_kunnr FOR ycis_apprvl-kunnr,
                s_kvgr2 FOR ycis_apprvl-kvgr2.
SELECTION-SCREEN END OF BLOCK b1.

*--------------------------------------------------------------------*
START-OF-SELECTION.
  PERFORM check_auth.
  IF gv_auth IS INITIAL.
    MESSAGE 'You are not maintained as a Level-4 (CPC Finance) approver (YCIS_WF_APPR)' TYPE 'I'.
    RETURN.
  ENDIF.
  PERFORM get_pending.
  IF gt_appr IS INITIAL.
    MESSAGE 'No rebate records pending your (L4) financial vetting' TYPE 'I'.
    RETURN.
  ENDIF.
  PERFORM build_out.
  PERFORM build_fieldcat.
  PERFORM display_alv.

*&---------------------------------------------------------------------*
FORM check_auth.
  DATA lv_cnt TYPE i.
  SELECT COUNT(*) INTO lv_cnt FROM ycis_wf_appr
    WHERE wf_level = gc_level AND userid = sy-uname.
  IF lv_cnt > 0.
    gv_auth = 'X'.
  ENDIF.
ENDFORM.

*&---------------------------------------------------------------------*
FORM get_pending.
  SELECT * FROM ycis_apprvl INTO TABLE gt_appr
    WHERE wf_status   = '40'                        " Pending L4
      AND scheme_type = gc_scheme                   " rebate queue only
      AND sales_off   IN s_vkbur
      AND period_from IN s_sptag
      AND kunnr       IN s_kunnr
      AND kvgr2       IN s_kvgr2.
ENDFORM.

*&---------------------------------------------------------------------*
FORM build_out.
  REFRESH gt_out.
  LOOP AT gt_appr INTO gs_appr.
    CLEAR gs_out.
    MOVE-CORRESPONDING gs_appr TO gs_out.
    APPEND gs_out TO gt_out.
  ENDLOOP.
ENDFORM.

*&---------------------------------------------------------------------*
FORM build_fieldcat.
  DATA: lv_pos TYPE i.
  DEFINE add_fc.
    CLEAR gs_fcat.
    ADD 1 TO lv_pos.
    gs_fcat-col_pos   = lv_pos.
    gs_fcat-fieldname = &1.
    gs_fcat-seltext_l = &2.
    gs_fcat-seltext_m = &2.
    gs_fcat-seltext_s = &2.
    gs_fcat-checkbox  = &3.
    gs_fcat-edit      = &3.
    APPEND gs_fcat TO gt_fcat.
  END-OF-DEFINITION.

  add_fc 'SEL'         'Select'          'X'.
  add_fc 'KUNNR'       'Customer'        ''.
  add_fc 'CUST_NAME'   'Customer Name'   ''.
  add_fc 'KVGR2'       'Grp Co.'         ''.
  add_fc 'SALES_OFF'   'Sales Office'    ''.
  add_fc 'REB_COND'    'Cond. Type'      ''.
  add_fc 'LFT_QTY'     'Lifted Qty'      ''.
  add_fc 'ELIG_QTY'    'Eligible Qty'    ''.
  add_fc 'REBATE_VAL'  'Rebate Value'    ''.
  add_fc 'PURCH_NO'    'Reference No'    ''.
  add_fc 'ORDER_NO'    'Rebate Order'    ''.
  add_fc 'L1_USER'     'L1 Verified By'  ''.
  add_fc 'L2_USER'     'L2 Verified By'  ''.
  add_fc 'L3_USER'     'L3 Executed By'  ''.
  add_fc 'L3_DATE'     'L3 Executed On'  ''.
  add_fc 'REMARKS'     'Remarks'         ''.
ENDFORM.

*&---------------------------------------------------------------------*
FORM display_alv.
  gs_layout-zebra         = 'X'.
  gs_layout-box_fieldname = 'SEL'.
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program       = sy-repid
      i_callback_pf_status_set = 'SET_STATUS'
      i_callback_user_command  = 'USER_COMMAND'
      i_callback_top_of_page   = 'TOP_OF_PAGE'
      is_layout                = gs_layout
      it_fieldcat              = gt_fcat
    TABLES
      t_outtab                 = gt_out
    EXCEPTIONS
      program_error            = 1
      OTHERS                   = 2.
ENDFORM.

*&---------------------------------------------------------------------*
FORM top_of_page.                                           "#EC CALLED
  DATA: lt_hdr TYPE slis_t_listheader,
        ls_hdr TYPE slis_listheader.
  CLEAR ls_hdr. ls_hdr-typ = 'H'.
  ls_hdr-info = 'Rebate (PSD) - Level-4 Financial Vetting (CPC Finance)'.
  APPEND ls_hdr TO lt_hdr.
  CLEAR ls_hdr. ls_hdr-typ = 'S'.
  ls_hdr-info = 'Credit-memo requests created at L3 are presented for financial vetting.'.
  APPEND ls_hdr TO lt_hdr.
  CLEAR ls_hdr. ls_hdr-typ = 'S'.
  ls_hdr-info = 'On vetting, the request is forwarded to L5 (CPC Head) for final approval.'.
  APPEND ls_hdr TO lt_hdr.
  CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'
    EXPORTING
      it_list_commentary = lt_hdr.
ENDFORM.

*&---------------------------------------------------------------------*
FORM set_status USING rt_extab TYPE slis_t_extab.            "#EC CALLED
  SET PF-STATUS 'STANDARD' EXCLUDING rt_extab.
ENDFORM.

*&---------------------------------------------------------------------*
FORM user_command USING r_ucomm     LIKE sy-ucomm            "#EC CALLED
                        rs_selfield TYPE slis_selfield.
  DATA: lr_grid TYPE REF TO cl_gui_alv_grid.
  CALL FUNCTION 'GET_GLOBALS_FROM_SLVC_FULLSCR'
    IMPORTING
      e_grid = lr_grid.
  IF lr_grid IS NOT INITIAL.
    CALL METHOD lr_grid->check_changed_data.
  ENDIF.
  CASE r_ucomm.
    WHEN 'APPR'.
      PERFORM process_selected USING 'A'.
      rs_selfield-refresh = 'X'.
    WHEN 'REJ'.
      PERFORM process_selected USING 'R'.
      rs_selfield-refresh = 'X'.
    WHEN 'SELALL'.
      LOOP AT gt_out INTO gs_out.
        gs_out-sel = 'X'. MODIFY gt_out FROM gs_out.
      ENDLOOP.
      rs_selfield-refresh = 'X'.
    WHEN 'DESEL'.
      LOOP AT gt_out INTO gs_out.
        CLEAR gs_out-sel. MODIFY gt_out FROM gs_out.
      ENDLOOP.
      rs_selfield-refresh = 'X'.
  ENDCASE.
ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  process_selected   (A = vet/approve, R = reject)
*&---------------------------------------------------------------------*
FORM process_selected USING p_action TYPE char1.
  DATA: lv_appr   TYPE i,
        lv_rej    TYPE i,
        lv_remark TYPE ycis_apprvl-rej_remarks.

  READ TABLE gt_out INTO gs_out WITH KEY sel = 'X'.
  IF sy-subrc <> 0.
    MESSAGE 'Please select at least one line' TYPE 'I'.
    RETURN.
  ENDIF.

  IF p_action = 'R'.
    PERFORM get_reject_remark CHANGING lv_remark.
    IF lv_remark IS INITIAL.
      MESSAGE 'Reject remark is mandatory' TYPE 'I'.
      RETURN.
    ENDIF.
  ENDIF.

  LOOP AT gt_out INTO gs_out WHERE sel = 'X'.
    READ TABLE gt_appr INTO gs_appr
         WITH KEY kunnr     = gs_out-kunnr
                  kvgr2     = gs_out-kvgr2
                  sales_off = gs_out-sales_off.
    CHECK sy-subrc = 0.
    IF p_action = 'A'.
      gs_appr-wf_status = '50'.          " Pending L5 (CPC Head)
      gs_appr-status    = 'P'.
      gs_appr-l4_user   = sy-uname.
      gs_appr-l4_date   = sy-datum.
      gs_appr-l4_time   = sy-uzeit.
      gs_appr-rem_l4    = 'L4 financially vetted'.
      gs_appr-remarks   = 'L4 financially vetted'.
      lv_appr = lv_appr + 1.
    ELSE.
      gs_appr-wf_status   = '30'.        " back to L3
      gs_appr-status      = 'P'.
      gs_appr-rej_level   = gc_level.
      gs_appr-rej_by      = sy-uname.
      gs_appr-rej_date    = sy-datum.
      gs_appr-rej_time    = sy-uzeit.
      gs_appr-rej_remarks = lv_remark.
      gs_appr-rem_l4      = lv_remark.
      gs_appr-remarks     = 'Returned by L4'.
      lv_rej = lv_rej + 1.
    ENDIF.
    MODIFY ycis_apprvl FROM gs_appr.
  ENDLOOP.

  IF lv_appr > 0 OR lv_rej > 0.
    COMMIT WORK.
  ENDIF.
  IF lv_appr > 0.
    PERFORM send_mail USING 'F' '5'.      " forward to L5
  ENDIF.
  IF lv_rej > 0.
    PERFORM send_mail USING 'R' '3'.      " reject back to L3
  ENDIF.
  DELETE gt_out WHERE sel = 'X'.
  MESSAGE |{ lv_appr } vetted & forwarded to L5, { lv_rej } returned to L3| TYPE 'S'.
ENDFORM.

*&---------------------------------------------------------------------*
FORM get_reject_remark CHANGING p_remark TYPE ycis_apprvl-rej_remarks.
  DATA: lt_fields TYPE STANDARD TABLE OF sval,
        ls_field  TYPE sval,
        lv_ret    TYPE char1.
  ls_field-tabname   = 'YCIS_APPRVL'.
  ls_field-fieldname = 'REJ_REMARKS'.
  ls_field-field_obl = 'X'.
  APPEND ls_field TO lt_fields.
  CALL FUNCTION 'POPUP_GET_VALUES'
    EXPORTING
      popup_title     = 'Reject remark'
    IMPORTING
      returncode      = lv_ret
    TABLES
      fields          = lt_fields
    EXCEPTIONS
      error_in_fields = 1
      OTHERS          = 2.
  IF sy-subrc = 0 AND lv_ret <> 'A'.
    READ TABLE lt_fields INTO ls_field INDEX 1.
    p_remark = ls_field-value.
  ENDIF.
ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  send_mail   (p_kind F=forward/R=reject, p_tolevel=target level)
*&      All L3-L6 recipients are central (sales office '0001').
*&---------------------------------------------------------------------*
FORM send_mail USING p_kind    TYPE char1
                     p_tolevel TYPE ycis_wlevel.
  DATA: lt_wf   TYPE STANDARD TABLE OF ycis_wf_appr,
        ls_wf   TYPE ycis_wf_appr,
        lo_send TYPE REF TO cl_bcs,
        lo_doc  TYPE REF TO cl_document_bcs,
        lo_rec  TYPE REF TO if_recipient_bcs,
        lt_text TYPE bcsy_text,
        ls_text TYPE soli,
        lv_addr TYPE ad_smtpadr,
        lv_sub  TYPE so_obj_des.

  SELECT * FROM ycis_wf_appr INTO TABLE lt_wf
    WHERE wf_level = p_tolevel AND sales_office = '0001'.
  CHECK lt_wf IS NOT INITIAL.

  TRY.
      lo_send = cl_bcs=>create_persistent( ).
      CLEAR lt_text.
      ls_text-line = |Dear Sir/Madam,|.                              APPEND ls_text TO lt_text.
      ls_text-line = ||.                                             APPEND ls_text TO lt_text.
      IF p_kind = 'F'.
        ls_text-line = |Financial vetting of the rebate (PSD) orders has been completed by L4 (CPC Finance).|.
        APPEND ls_text TO lt_text.
        ls_text-line = |Please log in and Review & Approve (Final Approval - L5).|.
        APPEND ls_text TO lt_text.
        lv_sub = 'Rebate (PSD) - Financially Vetted, Action Required at L5'.
      ELSE.
        ls_text-line = |The rebate (PSD) orders have been returned by L4 (CPC Finance) for your review.|.
        APPEND ls_text TO lt_text.
        ls_text-line = |Please log in to the L3 (CPC) execution screen and re-check the records.|.
        APPEND ls_text TO lt_text.
        lv_sub = 'Rebate (PSD) - Returned by L4 to L3'.
      ENDIF.
      ls_text-line = ||.                                             APPEND ls_text TO lt_text.
      ls_text-line = |This is a system generated mail. Please do not reply.|.
      APPEND ls_text TO lt_text.
      lo_doc = cl_document_bcs=>create_document(
                 i_type = 'RAW' i_text = lt_text i_subject = lv_sub ).
      lo_send->set_document( lo_doc ).
      LOOP AT lt_wf INTO ls_wf.
        CHECK ls_wf-email IS NOT INITIAL.
        lv_addr = ls_wf-email.
        lo_rec  = cl_cam_address_bcs=>create_internet_address( lv_addr ).
        lo_send->add_recipient( i_recipient = lo_rec ).
      ENDLOOP.
      lo_send->set_send_immediately( 'X' ).
      lo_send->send( i_with_error_screen = 'X' ).
      COMMIT WORK.
    CATCH cx_bcs.
  ENDTRY.
ENDFORM.
