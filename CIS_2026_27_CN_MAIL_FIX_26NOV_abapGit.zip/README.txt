CIS 2026-27 - fix 26.11.2026: credit note e-mail only to the customer's own e-mail ID(s)
abapGit: Import zip > Pull - YCIS_DISBURSE (YRVG004_P, L6). Contains also the fixes of 24.11.2026.
