CLASS zbp_zdpr_excel_dl DEFINITION
  PUBLIC ABSTRACT FINAL
  FOR BEHAVIOR OF zdpr_i_excel_dl.

  PUBLIC SECTION.
ENDCLASS.

CLASS zbp_zdpr_excel_dl IMPLEMENTATION.
ENDCLASS.

"-- Handler class for static download actions (Excel + PDF) -----------------
