CIS 2026-27 - PDR fixes 24.11.2026 (mails "CPC L6 Issues" and "45 min for generation of rebate orders")

abapGit standalone: New Offline (or existing offline repo) > Import zip > Pull. 5 programs:
  YCIS_APPRV5   (YRVG004_F, L5)  - L6 e-mail: L6 approvers found under any sales office, e-mail from SU01
                                   if blank; message says whether L6 was e-mailed
  YCIS_DISBURSE (YRVG004_P, L6)  - POST: SAP's own reason for every line not posted (Remarks + result
                                   list), billing block named; failed lines stay on the screen
  YCIS_EXECUTE  (YRVG004_E, L3)  - more than 20 lines: parallel background jobs YCIS_L3_REBATE_ORDERS
                                   (SM37), line locks, SAP reason in Remarks, L4 mailed once
  YCIS_APPROVE, YCIS_VET          - same e-mail recipient fix (L3 / L5 mails)

Checks in PDR:
  - L3 users: authorisation S_BTCH_JOB JOBACTION RELE (release own jobs). Without it the lines run in
    dialog as before.
  - YCIS_WF_APPR: level 6 entry with user ID and e-mail ID (or e-mail in SU01).
  - L6: POST one line - the Remarks column / result list shows why SAP did not create the credit note.
